Market 1501 数据集已经成为行人重识别领域最常用的数据集之一。

step1: 下载 Market-1501-v15.09.15 数据集
step2: 执行 prepare_person.py 生成训练需要的数据集形式
step3: 执行 train.py 训练 deep